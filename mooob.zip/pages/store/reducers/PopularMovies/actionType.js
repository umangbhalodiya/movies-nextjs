export const AllPopularMovies = "AllPopularMovies";
