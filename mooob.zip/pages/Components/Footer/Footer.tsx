import Image from "next/image";
import React from "react";

const Footer = () => {
  return (


    <div className=""> </div>


  )
};

export default Footer;
